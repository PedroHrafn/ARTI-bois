import java.util.Collection;
import java.util.Random;

public class RandomAgent implements Agent {
	private Random random = new Random();

	public String nextAction(Collection<String> percepts) {
		System.out.print("perceiving:");
		for (String percept : percepts) {
			System.out.print("'" + percept + "', ");
		}
		System.out.println("");
		String[] actions = { "TURN_ON", "TURN_OFF", "TURN_RIGHT", "TURN_LEFT", "GO", "SUCK" };
		return actions[random.nextInt(actions.length)];
	}

	public void reset() {

	}
}
